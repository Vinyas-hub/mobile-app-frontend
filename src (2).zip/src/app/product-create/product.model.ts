//product.model.ts
export interface Product {
    id: number | null;
    code: string;
    description: string;
    price: number;
    stock: number;
    idBrand: number | null; // Assuming idBrand is a foreign key to the Brand
  }
  