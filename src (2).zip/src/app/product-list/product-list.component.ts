//product-list
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products: any[] = [];
  selectedBrand: string = '';
  updatedData: any = {}; // Add this variable to hold updated data for editing

  constructor(private dataService: DataService,private productService: DataService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.selectedBrand = params['brand'];

      this.dataService.getProducts().subscribe(data => {
        if (this.selectedBrand) {
          this.products = data.filter((product: { brand: string; }) => product.brand === this.selectedBrand);
        } else {
          this.products = data;
        }
      });
    });
  }

  // deleteProduct(productId: number): void {
  //   this.dataService.deleteProduct(productId).subscribe(
  //     () => {
  //       // Remove the deleted product from the list
  //       this.products = this.products.filter(product => product.id !== productId);
  //       console.log(`Product with ID ${productId} deleted successfully.`);
  //     },
  //     error => console.error(`Error deleting product with ID ${productId}`, error)
  //   );
  // }
  // // deleteProduct(id: number): void {
  // //   this.ProductService.deleteProduct(id).subscribe(
  // //     () => {
  // //       // Remove the deleted product from the list
  // //       this.products = this.products.filter(product => product.id !== id);
  // //       console.log(`Product with id ${id} deleted successfully.`);
  // //     },
  // //     error => console.error(`Error deleting product with id ${id}`, error)
  // //   );
  // // }

  // editProduct(productId: number): void {
  //   // Find the product in the list
  //   const product = this.products.find(p => p.id === productId);

  //   if (product) {
  //     // Assign the product data to updatedData for editing
  //     this.updatedData = { ...product };
  //   }
  // }

  // saveEditedProduct(): void {
  //   if (this.updatedData.id) {
  //     this.dataService.updateProduct(this.updatedData.id, this.updatedData).subscribe(
  //       updatedProduct => {
  //         // Update the product in the list with the new data
  //         const index = this.products.findIndex(product => product.id === this.updatedData.id);
  //         if (index !== -1) {
  //           this.products[index] = updatedProduct;
  //           console.log(`Product with ID ${this.updatedData.id} updated successfully.`);
  //         }
  //       },
  //       error => console.error(`Error updating product with ID ${this.updatedData.id}`, error)
  //     );
  //   }
  // }
}
