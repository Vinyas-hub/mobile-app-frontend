// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute, Router } from '@angular/router';
// import { ProductService } from '../product-create/product-service';
// import { Product } from '../product-create/product.model';
// @Component({
//   selector: 'app-product-edit',
//   templateUrl: './product-edit.component.html',
//   styleUrls: ['./product-edit.component.css']
// })
// export class ProductEditComponent implements OnInit {
//   id: number;
//   product: Product = { id: null, code: '', description: '', price: 0, stock: 0, idBrand: null };

//   constructor(
//     private productService: ProductService,
//     private route: ActivatedRoute,
//     private router: Router
//   ) { }

//   ngOnInit(): void {
//     this.route.params.subscribe(params => {
//       this.productId = +params['id'];
//       this.productService.getProduct(this.productId).subscribe(
//         product => this.product = product,
//         error => console.error('Error fetching product', error)
//       );
//     });
//   }

//   updateProduct(): void {
//     if (this.product.code.trim() && this.product.description.trim() && this.product.price >= 0 && this.product.stock >= 0 && this.product.idBrand) {
//       this.productService.updateProduct(this.productId, this.product).subscribe(() => {
//         this.router.navigate(['/products']);
//       });
//     }
//   }
// }
