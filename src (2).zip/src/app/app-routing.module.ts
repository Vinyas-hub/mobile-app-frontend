import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BrandListComponent } from './brand-list/brand-list.component';
import { ProductListComponent } from './product-list/product-list.component';
import { CartComponent } from './cart/cart.component';
import { HomeComponent } from './home/home.component';
import { BrandCreateComponent } from './brand-create/brand-create.component';
//import { BrandDetailsComponent } from './brand-details/brand-details.component';
import { ProductCreateComponent } from './product-create/product-create.component';
const routes: Routes = [
  
  { path: 'brands', component: BrandListComponent },
  { path: 'brands/create', component: BrandCreateComponent }, 
// { path: 'brands/:id', component: BrandDetailsComponent },
  { path: 'products', component: ProductListComponent },
  { path: 'products/create', component: ProductCreateComponent },
  { path: 'products/:brand', component: ProductListComponent },
  { path: 'home', component: HomeComponent },
  { path: 'cart', component: CartComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
