// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute, Router } from '@angular/router';
// import { BrandService } from '../brand-create/brand-service';
// import { Brand } from '../brand-create/brand.model';

// @Component({
//   selector: 'app-brand-details',
//   templateUrl: './brand-details.component.html',
//   styleUrls: ['./brand-details.component.css']
// })
// export class BrandDetailsComponent implements OnInit {

//   brand!: Brand;

//   constructor(
//     private route: ActivatedRoute,
//     private brandService: BrandService,
//     private router: Router
//   ) {}

//   ngOnInit(): void {
//     this.getBrand();
//   }

//   getBrand(): void {
//     const id = +this.route.snapshot.paramMap.get('id')!;
//     console.log('ID:', id); // Check if this logs the correct ID
//     this.brandService.getBrand(id)
//       .subscribe((brand: Brand) => this.brand = brand);
//   }
  
//   deleteBrand(): void {
//     const id = +this.route.snapshot.paramMap.get('id')!;
//     this.brandService.deleteBrand(id)
//       .subscribe(() => {
//         this.router.navigate(['/brands']); // Navigate back to the brand list after deletion
//       });
//   }

// }