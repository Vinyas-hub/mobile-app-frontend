//brand-list
import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router'; // Import Router

@Component({
  selector: 'app-brand-list',
  templateUrl: './brand-list.component.html',
  styleUrls: ['./brand-list.component.css']
})
export class BrandListComponent implements OnInit {
  brands: any[]=[];

  constructor(private dataService: DataService, private router: Router) { }

  ngOnInit(): void {
    this.dataService.getBrands().subscribe(data => {
      this.brands = data;
      this.loadBrands();
    });
  }
  loadBrands(): void {
    this.dataService.getBrands().subscribe(
      brands => this.brands = brands,
      error => console.error('Error fetching brands', error)
    );
  }
  showProducts(brandName: string) {
    // Navigate to product list page with brandName as parameter
    this.router.navigate(['/products', { brand: brandName }]);
  }
  deleteBrand(id: number): void {
    this.dataService.deleteBrand(id).subscribe(
      () => {
        // Remove the deleted brand from the list
        this.brands = this.brands.filter(brand => brand.id !== id);
        console.log(`Brand with id ${id} deleted successfully.`);
      },
      error => console.error(`Error deleting brand with id ${id}`, error as any)
    );
  }
}
// ngOnInit(): void {
//   this.loadBrands();
// }

