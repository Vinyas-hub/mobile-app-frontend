//brand.model.ts
export interface Brand {
    id: number| null;
    name: string;
  }