import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http: HttpClient) { }

  getBrands(): Observable<any> {
    return this.http.get('http://localhost:8087/brands');
  }

  getProducts(): Observable<any> {
    return this.http.get('http://localhost:8087/products');
  }

  getCartItems(): Observable<any> {
    return this.http.get('http://localhost:8087/cart/items');
  }
  getProductById(productId: number): Observable<any> {
    return this.http.get(`http://localhost:8087/products/${productId}`);
  }
  updateProduct(productId: number, productData: any): Observable<any> {
    return this.http.put(`http://localhost:8087/products/${productId}`, productData);
  }
}
