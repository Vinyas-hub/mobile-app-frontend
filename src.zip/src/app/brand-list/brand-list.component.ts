import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router'; // Import Router

@Component({
  selector: 'app-brand-list',
  templateUrl: './brand-list.component.html',
  styleUrls: ['./brand-list.component.css']
})
export class BrandListComponent implements OnInit {
  brands: any[]=[];

  constructor(private dataService: DataService, private router: Router) { }

  ngOnInit(): void {
    this.dataService.getBrands().subscribe(data => {
      this.brands = data;
    });
  }

  showProducts(brandName: string) {
    // Navigate to product list page with brandName as parameter
    this.router.navigate(['/products', { brand: brandName }]);
  }
}
