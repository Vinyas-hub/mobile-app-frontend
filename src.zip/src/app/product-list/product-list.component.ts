import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products: any[] = [];
  selectedBrand: string = '';

  constructor(private dataService: DataService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.selectedBrand = params['brand'];

      this.dataService.getProducts().subscribe(data => {
        if (this.selectedBrand) {
          this.products = data.filter((product: { brand: string; }) => product.brand === this.selectedBrand);
        } else {
          this.products = data;
        }
      });
    });
  }
}
